<?php
namespace app\common\exception;

use think\Exception;

class CheckException extends Exception
{
    
}
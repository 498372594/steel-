<?php

namespace app\admin\controller;

use app\admin\library\traits\Backend;
use think\Db;
use think\Exception;
use think\Session;

class Riskcontrol extends Right
{
    use Backend;
    public function instorageinit(){

    }
}
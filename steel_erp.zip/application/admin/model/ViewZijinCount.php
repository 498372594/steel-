<?php


namespace app\admin\model;


class ViewZijinCount extends Base
{

}
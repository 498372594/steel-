<?php

namespace app\admin\model;
class ViewJxfpmxhx extends Base
{
    protected $autoWriteTimestamp = 'datetime';


}

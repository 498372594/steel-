<?php

namespace app\admin\model;
class ViewInv extends Base
{
    protected $autoWriteTimestamp = 'datetime';


}

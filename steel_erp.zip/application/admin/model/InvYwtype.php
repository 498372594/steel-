<?php

namespace app\admin\model;

use traits\model\SoftDelete;

class InvYwtype extends Base
{

}
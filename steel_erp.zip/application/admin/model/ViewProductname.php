<?php

namespace app\admin\model;

class ViewProductname extends Base
{    protected $autoWriteTimestamp = 'datetime';
    // 验证规则
    public $rules = [
        
    ];

    // 验证错误信息
    public $msg = [
        
    ];

    // 场景
    public $scene = [
        
    ];

    // 表单-数据表字段映射
    public $map = [
       
    ];
}

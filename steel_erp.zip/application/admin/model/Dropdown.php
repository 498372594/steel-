<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019-04-16
 * Time: 10:40
 */

namespace app\admin\model;


use think\Model;

class Dropdown extends Model
{

}